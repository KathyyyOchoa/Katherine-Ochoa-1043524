todayDay= hoy ().dia 
todayMonth= hoy ().mes 
todayyear= hoy().año

print(input("ingre su fecha")) 
print(input("dia"))
input("dayOfBirth")
print(input("mes"))
input("momthOfBirt") 

print(input("la fecha de hoy es:"+ todayDay+"-"+todayDay+"-"+todayDay))

ague= todayyear - yearofBirth
if (todayyear< yearOfBirth)
print(input("usted no nace"))
elif todayyear = = yearofbirthay
if monthOfBirth <todayMonth
print(input("usted aun no nace"))
elif monthofbirth = = todayMonth
if todayDay < dayofbirth
print(input("usted aun no nace"))
else
print(input("tiene ceros años"))
else
print(input("tiene ceros años"))
else
if monthOfBirth == todayMonth y dayOfBirth > todayDay o monthOfBirth > todayMonth
age = age -1
print(input("usted tiene" + age + "años"))

from datetime import date
date.today()//Fecha de hoy
date.today().day
date.today().month