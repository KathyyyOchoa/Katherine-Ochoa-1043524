def cuento(nombre,edad):
    listaCuento1 = [] 
    secuencia1 = f"""
En una pradera verde, bajo el cielo azul, 
vivía un arbol llamado {nombre}, tan menudo y gentil.
Con apenas {edad} añitos, miraba sin parar hacia el sol
 y a su amiga la roca.
"""
  

    secuencia2 = f"""
{nombre} amaba los paisajes simples y dulces, 
las flores silvestres y los suaves arbustos. 
Descubría el mundo, era todo un arbolito fiel.
"""
    secuencia4 = f"""
En aquel lugar, tan tranquilo y risueño,
{nombre} se llenaba de nieve.
un dia, aparecio un muñeco de nieve
{nombre} se puso muy feliz.
"""
    

    secuencia3 = f"""
Entre los cambios de estacion y clima,
{nombre} cambio de repente.
Sus hojas se tornaron anaranjadas, y poco a poca caian,
debajo de el habian manzanas caidas.
"""

    secuencia5 = f"""
Asi pasaban los días, llenos de risas y paz,
{nombre} y el muñeco de nieve se hicieron muy amigos.
Pasaron los dias y el muñeco tristemente se derritio.
Aun asi ambos eran muy felices.
"""

    

    listaCuento1.append(secuencia1)
    listaCuento1.append(secuencia2)
    listaCuento1.append(secuencia3)
    listaCuento1.append(secuencia4)
    listaCuento1.append(secuencia5)

    return listaCuento1



#{estrofa1, estrofa2, estrofa3}
