from Util import *

matriz = creandoMatriz()

imprimirMatriz(matriz)

agregarPiezas(matriz)

numero, nLetras = agregarTorre(matriz)

imprimirMatriz(matriz)

movimientosHechos = validarMovimientos(matriz, numero-1, nLetras-1)

for movimiento in movimientosHechos:
    if matriz[movimiento[0]-1][letrasAnumeros(movimiento[1])] == " * ":
       print(f"{movimiento[1]}{movimiento[0]}","vacio")
    else:
        print(f"{movimiento[1]}{movimiento[0]}", matriz[movimiento[0]-1][letrasAnumeros(movimiento[1])][0], matriz[movimiento[0]-1][letrasAnumeros(movimiento[0])][0], matriz[movimiento[0]-1][letrasAnumeros(movimiento[1])][1]) 

imprimirMatriz(matriz)

