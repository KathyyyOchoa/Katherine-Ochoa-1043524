def creandoMatriz():
    matriz = []
    for i in range(8):
        fila = []
        for j in range(8):
            fila.append(" * ")
        matriz.append(fila)
    return matriz

def mostrarLetras():
    columnas = ["  a ", " b "," c "," d "," e "," f "," g "," h "]
    for i in range(8):
        print(columnas[i], end = "")
    print("")


def imprimirMatriz(matriz): 
    mostrarLetras()
    contador = 7
    for i in range(8):
        print(i+1, end = "")
        for j in range(8):
            if matriz[i][j] == " * ":
               print(matriz[i][j], end = "")
            else:
                print(matriz[i][j][0], end = "")
        print("")
        contador -= 1
        


    #Tipo de pieza, color, pocision 
def agregarPiezas(matriz):
    piezas = int(input("ingrese cantidad de piezas: "))
    for i in range(piezas):
        piezas = []
        tipoPieza = 0
        while(tipoPieza < 1) or (tipoPieza > 6):
            print("""
            *** TIPO DE PIEZAS *** 
            1. Rey 
            2. Dama 
            3. Torre 
            4. Alfil 
            5. Caballo 
            6. Peon
            """)
            tipoPieza = int(input("Ingrese el tipo de pieza (1-6): "))
            if tipoPieza == 1:
                piezas.append(" R ")
            elif tipoPieza == 2:
                piezas.append(" D ")
            elif tipoPieza == 3:
                piezas.append(" T ")
            elif tipoPieza == 4:
                piezas.append(" A ")
            elif tipoPieza == 5:
                piezas.append(" C ")
            elif tipoPieza == 6:
                piezas.append(" P ")
            else: 
                print("no se ingreso una opcion valida")
                tipoPieza = 0

        colorPieza = 0
        while(colorPieza < 1) or (colorPieza > 2):
            print("""
            *** COLOR DE LA PIEZA *** 
            1. Blanca 
            2. Negra 
            """)
            colorPieza = int(input("Ingrese una opcion (1,2):"))
            if colorPieza == 1:
                piezas.append("blanca")
            elif colorPieza == 2:
                piezas.append("negra")
            else:
                print("No se ingreso una opcion valida")
                colorPieza = 0 

#Pocision dentro del tablero 
        letra = 0
        nLetra = 0
        numero = 0

        while(nLetra < 1 or nLetra > 8) or (numero < 1 or numero > 8):
            print("*** POSICION DE LA PIEZA ***")
            letra = input("Ingrese una letra entre (a-h): ")
            numero = int(input("Ingrese una letra entre (1-8): "))

            if letra == "a":
                nLetra = 1
            elif letra == "b":
                nLetra = 2
            elif letra == "c":
                nLetra = 3
            elif letra == "d":
                nLetra = 4
            elif letra == "e":
                nLetra = 5
            elif letra == "f":
                nLetra = 6
            elif letra == "g":
                nLetra = 7
            elif letra == "h":
                nLetra = 8
            else:
                print("No se ingreso una opcion valida")

#Ver si esta vacia o alguna pieza esta
        if matriz[numero-1][nLetra-1] == " * ":
            matriz[numero-1][nLetra-1] = piezas
        else:
            print("No se puede agregar en esta posicion")

#Pieza torre
def agregarTorre(matriz):
    print("*** AGREGANDO TORRE ***")
    pieza = [" T "]
    color = 0
    while (color < 1 or color > 2 ):
        print("""
        *** COLOR DE LA PIEZA ***
        1. Blanca 
        2. Negra 
        """)
        color = int(input("seleccione un color (1,2):"))
        if color == 1:
            pieza.append("blanca")
        elif color == 2:
            pieza.append("negra")
        else:
            print("No se ingreso una opcion valida")
            color = 0 

        #posicion tablero
    letra = 0
    nLetra = 0
    numero = 0

    while(nLetra < 1 or nLetra > 8) or (numero < 1 or numero > 8):
            print("*** POSICION DE LA TORRE ***")
            letra = input("Ingrese una letra entre (a-h): ")
            numero = int(input("Ingrese una letra entre (1-8): "))

            if letra == "a":
                nLetra = 1
            elif letra == "b":
                nLetra = 2
            elif letra == "c":
                nLetra = 3
            elif letra == "d":
                nLetra = 4
            elif letra == "e":
                nLetra = 5
            elif letra == "f":
                nLetra = 6
            elif letra == "g":
                nLetra = 7
            elif letra == "h":
                nLetra = 8
            else:
                print("No se ingreso una opcion valida")
                numero = 0
                continue

            if matriz[numero-1][nLetra-1] == " * ":
                matriz[numero-1][nLetra-1] = pieza 
            else: 
                print("No se puede agregar en esta posicion")
                numero 
            return numero, nLetra
    
def validarMovimientos(matriz, fila, columna):
    torre = matriz[fila][columna]
    color_torre = torre[1]

    movimientos = [] #guarda movimientos

    # validar movimientos hacia arriba 
    for i in range(fila-1, -1, -1):
        if matriz[i][columna] == " * ":
            movimientos.append([i+1, numeroAletras(columna+1)])
        elif matriz[i][columna][1] != color_torre: 
            movimientos.append([i+1, numeroAletras(columna+1)])
            break 
        else: 
            break
    
    #validar movimientos abajo 
    for i in range(fila+1,8):
        if matriz[i][columna]== " * ":
          movimientos.append([i+1, numeroAletras(columna+1)])
        elif matriz[i][columna][1] != color_torre:
          movimientos.append([i+1, numeroAletras(columna+1)])
          break 
        else:
            break

    #validar movimientos derecha
    for j  in range(columna + 1, 8):
        if matriz[fila][j] == " * ":
          movimientos.append([fila+1,numeroAletras(j+1)])
        elif matriz[fila][j][1] != color_torre:
          movimientos.append([fila+1,numeroAletras(j+1)])
          break 
        else:
            break

    #validad movimientos izquierda
    for j in range(fila-1, -1, -1):
        if matriz[fila][j] == " * ":
          movimientos.append([fila+1,numeroAletras(j+1)])
        elif matriz[fila][j][1] != color_torre:
          movimientos.append([fila+1,numeroAletras(j+1)])
          break 
        else: 
           break

    return movimientos 

def  numeroAletras(numero):
    letras = ["a", "b", "c","d", "e", "f","g", "h"]

    if 1 <= numero <= 8:
        return letras[numero -1]
    else:
        print("el numero no es correcto")

def letrasAnumeros(letras):

    letrasValidas = ["a", "b", "c","d", "e", "f","g", "h"]

    if letras in letrasValidas:
        return letrasValidas.index(letras)
    else:
        print("letra no valida")


 